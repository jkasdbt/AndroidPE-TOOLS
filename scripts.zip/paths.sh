# distro
export DISTRO_DIR="${DISTROS}/rootfs"

# base
export PATH="/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin"
export PATH="$PATH:/system/bin:/system/xbin:/usr/games:/usr/local/games:/snap/bin"
export PATH="$PATH:$DISTROS/_rkb"

# cmdline tools
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

# jdk
mkdir -p "$PRE_JAVA_HOME"
if [ ! -f "$PRE_JAVA_HOME/version.rkb" ] || [ "$( < "$PRE_JAVA_HOME/version.rkb")" = "null" ]; then
  echo "jdk-17.0.12" > "$PRE_JAVA_HOME/version.rkb"
fi


if [ -f "$PRE_JAVA_HOME/versionCustom.rkb" ]; then
  JAVA_VERSION=$(cat "$PRE_JAVA_HOME/versionCustom.rkb")
  export JAVA_HOME="$JAVA_VERSION"
  export PATH=$PATH:$JAVA_VERSION/bin
elif [ -f "$PRE_JAVA_HOME/version.rkb" ]; then
  JAVA_VERSION=$(cat "$PRE_JAVA_HOME/version.rkb")
  if [ $JAVA_VERSION="17.0.12" ]; then echo "jdk-17.0.12" > "$PRE_JAVA_HOME/version.rkb"; fi
  export JAVA_HOME="$PRE_JAVA_HOME/$JAVA_VERSION"
  export PATH=$PATH:$JAVA_HOME/bin
fi

# other
export DEBIAN_FRONTEND=noninteractive
export APT_PAGER=cat
export XPWD=$PWD
export PIP_BREAK_SYSTEM_PACKAGES=1
export ANDROID_PRINTF_LOG=all
export LD_WARN=0

export BASHRC=${HOME}/.bashrc
