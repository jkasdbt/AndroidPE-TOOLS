. $SCRIPTS/clrs.sh
. $SCRIPTS/links.sh

cmd="$1"
target="$2"
force="$3"

_help(){
  log "${BOLD} This lib is only to be used to install the tools."
  log "Know that it does not check if what you want to install is already present but forces the installation"
  echo ""
  log "install : install tools >> ndk, jdk(17|21|22|23|24)"
  log "setup   : setup AndroidPE tools >> ide"
  log "Add ${BOLD}'force' ${NC}at the end to force the installation even if this version is already installed."
}

_useHelp(){
  log "use 'rkb --help' for more details"
}

install_openjdk() {
  local TCP="$PWD"
  URL="$1"
  ARCHIVE_NAME="$(basename $URL)"
  
  if [ "$force" != "force" ]; then
    version=$(get_jdk_version "$URL")
    if [ -f "$PRE_JAVA_HOME/$version/bin/java" ] || [ -f "$PRE_JAVA_HOME/$version/jre/sh/java" ]; then
      _warning "This version ${NC}($version) ${WARNING}is already installed"
      log "Add ${BCYAN}(force) ${NC}at the end to force the installation"
      return 1
    fi
  fi
    
  mkdir -p "$PRE_JAVA_HOME"
  cd "$PRE_JAVA_HOME" || return 1

  log "Cleaning previous JDK installation..."
  rm -rf "$ARCHIVE_NAME"

  log "Downloading JDK from ${INFO}$URL..."
  
  wget -O "$ARCHIVE_NAME" "$URL" || {
    _warning "Download failed !"
    return 1
  }

  log "Extracting the archive..."
  tar -xf "$ARCHIVE_NAME"; _success "JDK installed" || {
    _error "Extraction failed !"
    return 1
  }
  cd "$TCP"
}

install_openjdk11() {
  local TCP="$PWD"
  
  URL="$jdk11"
  ARCHIVE_NAME="jdk11-aarch32.tar.xz"
  EXTRACTED_DIR="jdk"
  TARGET_DIR="openJDK-11"

  mkdir -p "$PRE_JAVA_HOME"
  cd "$PRE_JAVA_HOME" || return 1

  log "Cleaning previous JDK installation..."
  rm -rf "$ARCHIVE_NAME" "$EXTRACTED_DIR" "$TARGET_DIR"

  log "Downloading JDK from $URL..."
  wget -O "$ARCHIVE_NAME" "$URL" || {
    echo "Download failed!"
    return 1
  }

  log "Extracting the archive..."
  tar -xf "$ARCHIVE_NAME" || {
    echo "Extraction failed!"
    return 1
  }

  if [ -d "$EXTRACTED_DIR" ]; then
    mv "$EXTRACTED_DIR" "$TARGET_DIR"
    log ""
    if [ -f "$PRE_JAVA_HOME/$TARGET_DIR/bin/java" ]; then
      _success "JDK installed to $PRE_JAVA_HOME/$TARGET_DIR"
    fi
    log ""
  else
    error "!" "Error: Extracted folder '$EXTRACTED_DIR' not found!"
    return 1
  fi
  
  cd "$TCP"
}

_setupIde(){
  if [ "$ARCH_APP" = "64" ]; then
    install_openjdk "$jdk17"
  else
    install_openjdk11
  fi
  . $SCRIPTS/cmdline-tools.sh
  . $SCRIPTS/paths.sh
  
  if [ -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ] && [ -f "$PRE_JAVA_HOME/17.0.12/bin/java" ]; then
    log ""
    _success "[✓] ide setup finished"
    log ""
  else
    _error "[!!] The cmdline & jdk17 were not properly installed and configured."
    info "i" "Try again to reinstall."
  fi
  
  . $SCRIPTS/paths.sh
}

case "$cmd" in
  install)
    if [ "$target" = "ndk" ]; then
      TCP="$PWD"
      if [ -f "$HOME/ndk-installer.sh" ]; then rm $HOME/ndk-installer.sh; fi
      cd && wget https://github.com/jkasdbt/AndroidPE-NDK/raw/main/ndk-install.sh && chmod +x $HOME/ndk-install.sh && bash $HOME/ndk-install.sh
      cd "$TCP"
    elif [ "$target" = "cmdline" ]; then
      . $SCRIPTS/cmdline-tools.sh "$force"
    elif [ "$target" = "jdk24" ]; then
      install_openjdk "$jdk24"
    elif [ "$target" = "jdk23" ]; then
      install_openjdk "$jdk23"
    elif [ "$target" = "jdk22" ]; then
      install_openjdk "$jdk22"
    elif [ "$target" = "jdk21" ]; then
      install_openjdk "$jdk21"
    elif [ "$target" = "jdk17" ]; then
      install_openjdk "$jdk17"
    elif [ "$target" = "jdk11" ]; then
      install_openjdk11
    elif [ "$target" = "jdk8" ]; then
      _warning "This version is not yet configured."
    else
      info "*" "Use 'rkb install ndk', '... jdk17, cmdline, ...' or --help"
    fi
  ;;
  setup)
    if [ "$target" = "ide" ]; then
      _setupIde
    else
      info "*" "Use 'rkb setup ide' or --help"
    fi
  ;;
  --help|-h)
  _help
  ;;
  *)
    _useHelp
  ;;
esac