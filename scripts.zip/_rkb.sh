# AndroidPE - Your IDE in your pocket !
# 
# AndroidPE is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# AndroidPE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with AndroidPE.  If not, see <https://www.gnu.org/licenses/>.

. $SCRIPTS/clrs.sh
. $SCRIPTS/links.sh

cmd="$1"
target="$2"
force="$3"

_help(){
  log "${BOLD} This lib is only to be used to install the tools."
  log "Know that it does not check if what you want to install is already present but forces the installation"
  echo ""
  log "install : install tools >> ndk, jdk(17|21|22|23|24)"
  log "setup   : setup AndroidPE tools >> ide"
  log "Add ${BOLD}'force' ${NC}at the end to force the installation even if this version is already installed."
}

_useHelp(){
  log "use 'rkb --help' for more details"
}

install_openjdk() {
  local TCP="$PWD"
  URL="$1"
  ARCHIVE_NAME="$(basename $URL)"
  
  if [ "$force" != "force" ]; then
    version=$(get_jdk_version "$URL")
    if [ -f "$PRE_JAVA_HOME/$version/bin/java" ] || [ -f "$PRE_JAVA_HOME/$version/jre/sh/java" ]; then
      _warning "This version ${NC}($version) ${WARNING}is already installed"
      log "Add ${BCYAN}(force) ${NC}at the end to force the installation"
      return 1
    fi
  fi
    
  mkdir -p "$PRE_JAVA_HOME"
  cd "$PRE_JAVA_HOME" || return 1

  log "Cleaning previous JDK installation..."
  rm -rf "$ARCHIVE_NAME"

  log "Downloading JDK from ${INFO}$URL..."
  
  wget -O "$ARCHIVE_NAME" "$URL" || {
    _warning "Download failed !"
    return 1
  }

  log "Extracting the archive..."
  tar -xf "$ARCHIVE_NAME"; _success "JDK installed" || {
    _error "Extraction failed !"
    return 1
  }
  cd "$TCP"
}

_setupIde(){
  install_openjdk "$jdk17"
  . $SCRIPTS/cmdline-tools.sh
  . $SCRIPTS/paths.sh
  
  if [ -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ] && [ -f "$PRE_JAVA_HOME/17.0.12/bin/java" ]; then
  . $SCRIPTS/paths.sh
    log ""
    _success "[✓] ide setup finished"
    log ""
  else
    if [ ! -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
      _error "[!!] The cmdline not properly installed and configured."
      info "i" "Try again to reinstall (rkb install cmdline)."
    fi
  
    if [ ! -f "$JAVA_HOME/bin/java" ]; then
      _error "[!!] The JDK not properly installed and configured."
      info "i" "Try again to reinstall (rkb install jdk17)."
    fi
  fi
}

case "$cmd" in
  install)
    if [ "$target" = "ndk" ]; then
      TCP="$PWD"
      if [ -f "$HOME/ndk-installer.sh" ]; then rm $HOME/ndk-installer.sh; fi
      cd
      wget https://github.com/jkasdbt/AndroidPE-NDK/raw/main/ndk-install.sh --no-verbose --show-progress -N
      chmod +x $HOME/ndk-install.sh
      bash $HOME/ndk-install.sh
      cd "$TCP"
    elif [ "$target" = "cmdline" ]; then
      . $SCRIPTS/cmdline-tools.sh "$force"
    elif [ "$target" = "jdk24" ]; then
      install_openjdk "$jdk24"
    elif [ "$target" = "jdk23" ]; then
      install_openjdk "$jdk23"
    elif [ "$target" = "jdk22" ]; then
      install_openjdk "$jdk22"
    elif [ "$target" = "jdk21" ]; then
      install_openjdk "$jdk21"
    elif [ "$target" = "jdk17" ]; then
      install_openjdk "$jdk17"
    else
      info "*" "Use 'rkb install ndk', '... jdk17, cmdline, ...' or --help"
    fi
  ;;
  setup)
    if [ "$target" = "ide" ]; then
      . $SCRIPTS/init-distro.sh
      _setupIde
    else
      info "*" "Use 'rkb setup ide' or --help"
    fi
  ;;
  --help|-h)
  _help
  ;;
  *)
    _useHelp
  ;;
esac