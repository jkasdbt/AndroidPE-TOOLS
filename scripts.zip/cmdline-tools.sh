. $SCRIPTS/clrs.sh

force="$1"
URL="$cmdline"
DEST_DIR="$ANDROID_HOME/cmdline-tools/latest"
TMP_ZIP="$TMP_DIR/download/cmdline_tool.zip"
if [ "$force" = "force" ]; then rm -rf $DEST_DIR; fi
if [ ! -f "$DEST_DIR/bin/sdkmanager" ]; then
  if [ ! -d "$DEST_DIR" ]; then mkdir -p "$DEST_DIR"; fi
  info "*" "downloading cmdline-tools ..."
  if wget -q --no-verbose --show-progress -N -O "$TMP_ZIP" "$URL"; then
    info "*" "Extracting the archive ..."
      if unzip -q "$TMP_ZIP" -d "$DEST_DIR"; then
        mv "$ANDROID_HOME/cmdline-tools/latest/cmdline-tools/"* "$ANDROID_HOME/cmdline-tools/latest/"
        rm -r "$ANDROID_HOME/cmdline-tools/latest/cmdline-tools"
        info "*" "cleaning tmp archive..."
        rm "$TMP_ZIP"
        _success "cmdline-tools has been added"
        if [ -x "$DEST_DIR/bin/sdkmanager" ]; then
          log "[+] sdkmanager is ready to be used."
        else
          chmod +x "$DEST_DIR/bin/sdkmanager"
          if [ -x "$DEST_DIR/bin/sdkmanager" ]; then
            yes | sdkmanager --licenses
            log "[+] sdkmanager is now executable."
          else
            error "!" "Failed to make sdkmanager executable."
          fi    
        fi
      else
        fail "Échec de l’extraction de $TMP_ZIP"
      fi
    else
      _error "cmdline-tools has not been downloaded correctly"
    fi
fi
if command -v sdkmanager >/dev/null 2>&1; then
  (yes | sdkmanager --licenses > /tmp/sdk-licenses.log 2>&1) & disown
fi
