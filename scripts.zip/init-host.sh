stty -echo
. $SCRIPTS/args.sh
. $SCRIPTS/clrs.sh

if [ ! -f "$DISTROS/rootfs/bin/bash" ]; then
  _error "The rootfs was not installed correctly or is broken."
  _warning "Please reinstall it."
  log "Preferences ⟩ Terminal"
  log ""
  exit 404
fi

export PS1="${NC}"
exec $PROOT $ARGS sh $SCRIPTS/init-base.sh "$@"
