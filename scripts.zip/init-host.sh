. $SCRIPTS/args.sh
. $SCRIPTS/clrs.sh

if [ ! -f "$DISTROS/rootfs/bin/bash" ]; then
  _error "The rootfs was not installed correctly or is broken."
  _warning "Please reinstall it."
  log "Preferences/"
  log ""
  exit 43
fi
exec $PROOT $ARGS sh $SCRIPTS/init.sh "$@"