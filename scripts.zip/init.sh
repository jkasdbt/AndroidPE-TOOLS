. $SCRIPTS/clrs.sh
. $SCRIPTS/links.sh
. $SCRIPTS/paths.sh

cd "$2"

if [ "$1" = "compiler" ]; then export PS1="${NC}"
else . $SCRIPTS/msgw.sh; stty echo; fi
