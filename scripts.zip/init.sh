chmod +x $SCRIPTS/args.sh
chmod +x $SCRIPTS/clrs.sh
chmod +x $SCRIPTS/cmdline-tools.sh
chmod +x $SCRIPTS/init-distro.sh
chmod +x $SCRIPTS/init-host.sh
chmod +x $SCRIPTS/init.sh
chmod +x $SCRIPTS/links.sh
chmod +x $SCRIPTS/msgw.sh
chmod +x $SCRIPTS/paths.sh
chmod +x $DISTROS/_rkb/rkb

. $SCRIPTS/clrs.sh
. $SCRIPTS/links.sh
. $SCRIPTS/paths.sh

if [ "$1" = "compiler" ]; then
  stty -echo
else
  . $SCRIPTS/init-distro.sh
  if [ -f "${HOME}/.bash_history" ]; then
    export HISTFILE="${HOME}/.bash_history"
    history -r
  fi
fi

cd "$2"
exec /bin/bash