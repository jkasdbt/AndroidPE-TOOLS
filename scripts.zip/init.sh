stty -echo

. $SCRIPTS/clrs.sh
. $SCRIPTS/links.sh
. $SCRIPTS/paths.sh

ANDROID_GIDS="1077 1079 3003 9997 20621 20655 50621 50655 20657 50657"
for gid in $ANDROID_GIDS; do
  if ! grep -q ":$gid:" /etc/group; then
    echo "android_gid_$gid:x:$gid:" >> /etc/group
  fi
done

if [ "${cpl}" = "true" ]; then export PS1="${NC}"
else . $SCRIPTS/msgw.sh; stty echo; fi

alias ls='ls --color=auto'
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'

if [[ "${pjct}" == /storage/emulated/0* ]]; then
export pjct="/sdcard${pjct:19}"; fi

cd "${pjct}"
