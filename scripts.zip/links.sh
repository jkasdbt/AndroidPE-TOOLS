# AndroidPE - Your IDE in your pocket !
# 
# AndroidPE is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# AndroidPE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with AndroidPE.  If not, see <https://www.gnu.org/licenses/>.

# === DISTRO ===
rootfs64="https://cdimage.ubuntu.com/ubuntu-base/releases/plucky/release/ubuntu-base-25.04-base-arm64.tar.gz"
rootfs32="https://cdimage.ubuntu.com/ubuntu-base/releases/plucky/release/ubuntu-base-25.04-base-armhf.tar.gz"



# === JDK ===
jdk11="https://github.com/AndroidIDEOfficial/androidide-tools/releases/download/jdk-11/jdk11-aarch32.tar.xz"
jdk17="https://download.oracle.com/java/17/archive/jdk-17.0.12_linux-aarch64_bin.tar.gz"
jdk21="https://download.oracle.com/java/21/archive/jdk-21.0.7_linux-aarch64_bin.tar.gz"
jdk22="https://download.oracle.com/java/22/archive/jdk-22.0.2_linux-aarch64_bin.tar.gz"
jdk23="https://download.oracle.com/java/23/archive/jdk-23.0.2_linux-aarch64_bin.tar.gz"
jdk24="https://download.oracle.com/java/24/latest/jdk-24_linux-aarch64_bin.tar.gz"



# === jdt LANGUAGE SERVER ===
jdtls="https://www.eclipse.org/downloads/download.php?file=/jdtls/snapshots/jdt-language-server-latest.tar.gz"


get_jdk_version() {
  url="$1"
  if [ "$url" = "$jdk11" ]; then echo "openJDK-11"; fi
  if [ "$url" = "$jdk17" ]; then echo "jdk-17.0.12"; fi
  if [ "$url" = "$jdk21" ]; then echo "jdk-21.0.7"; fi
  if [ "$url" = "$jdk22" ]; then echo "jdk-22.0.2"; fi
  if [ "$url" = "$jdk23" ]; then echo "jdk-23.0.2"; fi
  if [ "$url" = "$jdk24" ]; then echo "jdk-24"; fi
}


# === CMDLINE-TOOLS ===
cmdline="https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip"