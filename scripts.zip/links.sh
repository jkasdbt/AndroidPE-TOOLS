# === DISTRO ===
rootfs64="https://cdimage.ubuntu.com/ubuntu-base/releases/plucky/release/ubuntu-base-25.04-base-arm64.tar.gz"
rootfs32="https://cdimage.ubuntu.com/ubuntu-base/releases/plucky/release/ubuntu-base-25.04-base-armhf.tar.gz"



# === JDK ===
jdk11="https://github.com/AndroidIDEOfficial/androidide-tools/releases/download/jdk-11/jdk11-aarch32.tar.xz"
jdk17="https://download.oracle.com/java/17/archive/jdk-17.0.12_linux-aarch64_bin.tar.gz"
jdk21="https://download.oracle.com/java/21/archive/jdk-21.0.7_linux-aarch64_bin.tar.gz"
jdk22="https://download.oracle.com/java/22/archive/jdk-22.0.2_linux-aarch64_bin.tar.gz"
jdk23="https://download.oracle.com/java/23/archive/jdk-23.0.2_linux-aarch64_bin.tar.gz"
jdk24="https://download.oracle.com/java/24/latest/jdk-24_linux-aarch64_bin.tar.gz"


get_jdk_version() {
  url="$1"
  if [ "$url" = "$jdk11" ]; then echo "openJDK-11"; fi
  if [ "$url" = "$jdk17" ]; then echo "jdk-17.0.12"; fi
  if [ "$url" = "$jdk21" ]; then echo "jdk-21.0.7"; fi
  if [ "$url" = "$jdk22" ]; then echo "jdk-22.0.2"; fi
  if [ "$url" = "$jdk23" ]; then echo "jdk-23.0.2"; fi
  if [ "$url" = "$jdk24" ]; then echo "jdk-24"; fi
}


# === CMDLINE-TOOLS ===
cmdline="https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip"