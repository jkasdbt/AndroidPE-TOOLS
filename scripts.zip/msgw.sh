. $SCRIPTS/clrs.sh

export PS1="\[\033[0;31m\]\342\224\214\342\224\200\$([[ \$? != 0 ]] && log \"[\[\033[0;31m\]\342\234\227\[\033[0;37m\]]\342\224\200\")[$(if [[ ${EUID} == 0 ]]; then log '\[\033[01;31m\]\u\[\033[01;33m\]@\[\033[01;96m\]rkb'; else log '\[\033[0;39m\]\u\[\033[01;33m\]@\[\033[01;96m\]rkb'; fi)\[\033[0;31m\]]\342\224\200[\[\033[0;32m\]\w\[\033[0;31m\]]\n\[\033[0;31m\]\342\224\224\342\224\200\342\224\200\342\225\274 \[\033[0m\]\[\e[01;33m\]$ \[\e[0m\]"

[ -n "$BASHRC" ] && [ -f "$BASHRC" ] && source "$BASHRC"

clear
log "${BOLD}Welcome to AndroidPE Terminal"
log ""
log "Community: https://t.me/AndroidPEOfficial"
log ""
log ""
log "Working with packages:"
log "   • Install : apt ${SUCCESS}install ${NC}<${ERROR}package${NC}>"
log "   • Update  : apt ${WARNING}update"
log "   • Upgrade : apt ${WARNING}upgrade"
log ""
log "Report issues on Telegram : 'issues & fixes' section"
log ""

if [ -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"  ]; then
    . $SCRIPTS/cmdline-tools.sh
else
    _warning " ('-') ! 'cmdline-tools' not Installed yet"
fi

if [ -f "$JAVA_HOME/bin/java" ]; then
    . $SCRIPTS/cmdline-tools.sh
else
    _warning " ('~') ! 'JDK' not Installed yet use : "
    _info2 "rkb setup ide"
    log ""
fi