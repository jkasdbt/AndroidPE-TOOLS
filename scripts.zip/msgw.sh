[ -n "$BASHRC" ] && [ -f "$BASHRC" ] && source "$BASHRC"

. $SCRIPTS/clrs.sh
. $SCRIPTS/links.sh
. $SCRIPTS/paths.sh

export PS1="\[\033[38;2;3;96;87m\]\342\224\214\342\224\200\$([[ \$? != 0 ]] && log \"(\[\033[0;31m\]✗\[\033[38;2;3;96;87m\])\342\224\200\")(\[\033[38;2;31;163;151m\]\[\033[1m\]\u\[\033[22m\]\[\033[38;2;3;96;87m\]@\[\033[38;2;31;163;151m\]\[\033[1m\]rkb\[\033[22m\]\[\033[38;2;3;96;87m\])\342\224\200[ \[\033[38;2;0;180;0m\]\[\033[1m\]\w\[\033[22m\]\[\033[38;2;3;96;87m\] ]\n\[\033[38;2;3;96;87m\]\342\224\224\342\224\200\342\224\200\342\225\274 \[\033[0m\]\$ "

clear

log "${BOLD}Welcome to AndroidPE Terminal"
log ""
log "Community: https://t.me/AndroidPEOfficial"
log ""
log ""
log "Working with packages:"
log "   • Search  : apt search <${WARNING}query${NC}>"
log "   • Install : apt install <${ERROR}package${NC}>"
log "   • Update  : apt ${BOLD}update"
log "   • Upgrade : apt ${BOLD}upgrade"
log ""
log "Report issues on Telegram : 'issues & fixes' section"
log ""

if [ -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"  ]; then
    . $SCRIPTS/cmdline-tools.sh
else
    _warning "'cmdline-tools' ${NC}not Installed yet"
fi

if [ -f "$JAVA_HOME/bin/java" ]; then
    . $SCRIPTS/cmdline-tools.sh
else
    _warning "'JDK' ${NC}not Installed yet use : "
    _info2 "rkb setup ide"
    log ""
fi
