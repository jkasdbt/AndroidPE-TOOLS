# AndroidPE - Your IDE in your pocket !
# 
# AndroidPE is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# AndroidPE is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with AndroidPE.  If not, see <https://www.gnu.org/licenses/>.

TMPDIR="$TMP_DIR/init-processing/rootfs"
REQUIRED_PKGS="locale apt-utils xz-utils tar wget zip curl bash unzip"

import_gpg_key() {
  local key_id="3B4FE6ACC0B21F32"
  local key_path="$DISTROS/rootfs/etc/apt/trusted.gpg.d/ubuntu.gpg"

  if gpg --list-keys "$key_id" >/dev/null 2>&1 || [ -f "$key_path" ]; then
    _success "GPG key already installed"
    return
  fi

  _warning "Missing GPG key"
  mkdir -p "$(dirname "$key_path")"

  apt update -y && apt install -y gpg

  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x$key_id" \
      | gpg --dearmor -o "$key_path"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x$key_id" \
      | gpg --dearmor -o "$key_path"
  else
    _warning "No curl or wget found, creating empty key file."
    touch "$key_path"
  fi
}

install_base_libs() {
  mkdir -p "$TMPDIR"
  local missing=""

  for pkg in $REQUIRED_PKGS; do
    command -v "$pkg" >/dev/null 2>&1 || missing+=" $pkg"
  done

  if [ -n "$missing" ]; then
    _info2 "Installing missing base packages..."
    _warning "$missing"
    apt update -y && apt install -y $missing
  fi
}

import_gpg_key
install_base_libs