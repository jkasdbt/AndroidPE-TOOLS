TMPDIR="$TMP_DIR/init-processing/rootfs"
PACKAGE_MANAGER="apt"
INSTALL_CMD="${PACKAGE_MANAGER} install "
UPDATE_CMD="${PACKAGE_MANAGER} update"
REQUIRED_PKGS="locales apt-utils xz-utils tar wget zip curl bash unzip"
  
import_gpg_key() {
  key_id="3B4FE6ACC0B21F32"
  key_path="$DISTROS/rootfs/etc/apt/trusted.gpg.d/ubuntu.gpg"

  if gpg --list-keys "$key_id" >/dev/null 2>&1 || [ -f "$key_path" ]; then
    _success "GPG key already installed"
  else
    _warning "Missing GPG key"
  fi

  download_ok=false
  
  mkdir -p "$DISTROS/rootfs/etc/apt/trusted.gpg.d"
  chmod 755 "$DISTROS/rootfs/etc/apt/trusted.gpg.d"
  touch $key_path
  yes | apt update
  yes | apt install gpg
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x$key_id" \
      | gpg --dearmor > "$key_path" && download_ok=true
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x$key_id" \
      | gpg --dearmor > "$key_path" && download_ok=true
  else
    _warning "No curl and wget found."
    touch $key_path
  fi
  touch $key_path
}

import_gpg_key

get_binary_for_pkg() {
  pkg="$1"
  case "$pkg" in
    build-essential)
      echo gcc ;;
    locales)
      echo locale ;;
    *)
      echo "$pkg" ;;
  esac
}

install_base_libs() {
  mkdir -p "$TMPDIR"
  chmod 1777 "$TMPDIR"

  command -v "$PACKAGE_MANAGER" 2>/dev/null
  if [ $? -ne 0 ]; then
    warning "!" "Package manager '$PACKAGE_MANAGER' not found. ${BOLD}Are you inside a valid rootfs ?"
    exit 1
  fi

  MISSING=""
  for pkg in $REQUIRED_PKGS; do
    if [ "$pkg" = "xz-utils" ]; then
      command -v xz >/dev/null 2>&1 || MISSING="$MISSING $pkg"
      continue
    fi

    if [ "$pkg" = "apt-utils" ]; then
      dpkg -s apt-utils >/dev/null 2>&1 || MISSING="$MISSING $pkg"
      continue
    fi

    binary=$(get_binary_for_pkg "$pkg")
    command -v "$binary" >/dev/null 2>&1 || MISSING="$MISSING $pkg"
  done

  if [ -n "$MISSING" ]; then
      _info2 "Updating and installing essential packages for the rootfs"
      _warning "${MISSING}, ..."
      yes | eval "$INSTALL_CMD $MISSING"
  fi
}

install_base_libs

ANDROID_GIDS="1077 1079 3003 9997 20621 20655 50621 50655"
for gid in $ANDROID_GIDS; do
  if ! grep -q ":$gid:" /etc/group; then
    log "Adding Android group ID $gid..."
    echo "android_gid_$gid:x:$gid:" >> /etc/group
  fi
done